# PoProjekt
Projekt wykonany na kurs Programowanie obiektowe 2018-19

Podział pracy:
- Jakub Górowski - Poject Manager, odpowiedzialny za weryfikację pracy pozostałych członków zespołu, twórca GUI i dokumantacji Sandcastle
- Dawid Ciochoń - twórca podstawowych klas projektu
- Adrian Gzyl - twórca metod klas, a także testów jednostkowych
- Mikołaj Brzozowski - twórca modelu CRC, a także odpowiedzialny za wygląd GUI

Dokumentacja Sandcastle znajduje się w folderze Dokumentacja/Help
